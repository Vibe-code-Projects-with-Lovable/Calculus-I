import { useState } from "react";
import { Copy, Check, Info } from "lucide-react";
import { MathBlock, RichText } from "@/lib/math";
import { Button } from "@/components/ui/button";
import type { Formula } from "@/data/chapters";

export function FormulaCard({ formula }: { formula: Formula }) {
  const [copied, setCopied] = useState(false);
  const [open, setOpen] = useState(false);

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(formula.latex);
      setCopied(true);
      setTimeout(() => setCopied(false), 1200);
    } catch {}
  };

  return (
    <div className="rounded-lg border border-border bg-card p-3 shadow-sm">
      <div className="mb-1 flex items-center justify-between gap-2">
        <span className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
          {formula.name}
        </span>
        <div className="flex items-center gap-1">
          <Button
            variant="ghost"
            size="icon"
            className="h-7 w-7"
            onClick={() => setOpen((o) => !o)}
            aria-label="Toggle meaning"
          >
            <Info className="h-3.5 w-3.5" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="h-7 w-7"
            onClick={copy}
            aria-label="Copy LaTeX"
          >
            {copied ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
          </Button>
        </div>
      </div>
      <MathBlock>{formula.latex}</MathBlock>
      {open && (
        <p className="mt-2 border-t border-border pt-2 text-xs text-muted-foreground">
          <RichText>{formula.meaning}</RichText>
        </p>
      )}
    </div>
  );
}

import { useMemo, useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { chapters } from "@/data/chapters";
import { MathInline, RichText } from "@/lib/math";

type Hit = {
  href: string;
  chapter: string;
  category: string;
  title: string;
  preview: string;
};

export function SearchDialog({
  open,
  onOpenChange,
  onPick,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  onPick: (href: string) => void;
}) {
  const [q, setQ] = useState("");

  const hits: Hit[] = useMemo(() => {
    if (!q.trim()) return [];
    const needle = q.toLowerCase();
    const out: Hit[] = [];
    for (const c of chapters) {
      const base = `/chapters/${c.id}`;
      if (c.title.toLowerCase().includes(needle))
        out.push({
          href: base,
          chapter: `Ch. ${c.number}`,
          category: "Chapter",
          title: c.title,
          preview: c.summary,
        });
      c.blocks.forEach((b) => {
        if (
          b.title.toLowerCase().includes(needle) ||
          b.body.toLowerCase().includes(needle)
        )
          out.push({
            href: base,
            chapter: `Ch. ${c.number}`,
            category: b.kind,
            title: b.title,
            preview: b.body.slice(0, 140),
          });
      });
      c.formulas.forEach((f) => {
        if (
          f.name.toLowerCase().includes(needle) ||
          f.latex.toLowerCase().includes(needle) ||
          f.meaning.toLowerCase().includes(needle)
        )
          out.push({
            href: base,
            chapter: `Ch. ${c.number}`,
            category: "Formula",
            title: f.name,
            preview: `$${f.latex}$`,
          });
      });
    }
    return out.slice(0, 20);
  }, [q]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Search the syllabus</DialogTitle>
        </DialogHeader>
        <Input
          autoFocus
          placeholder="Try 'Schwarz', 'radius', 'Lagrange', 'Parseval'…"
          value={q}
          onChange={(e) => setQ(e.target.value)}
        />
        <div className="max-h-96 overflow-y-auto">
          {hits.length === 0 && q && (
            <p className="px-1 py-6 text-center text-sm text-muted-foreground">
              No results for “{q}”.
            </p>
          )}
          <ul className="divide-y divide-border">
            {hits.map((h, i) => (
              <li key={i}>
                <button
                  onClick={() => onPick(h.href)}
                  className="flex w-full flex-col items-start gap-1 px-2 py-3 text-left hover:bg-muted/60"
                >
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <span className="rounded bg-secondary px-1.5 py-0.5">{h.chapter}</span>
                    <span className="uppercase tracking-wide">{h.category}</span>
                  </div>
                  <div className="font-medium">
                    <RichText>{h.title}</RichText>
                  </div>
                  <div className="line-clamp-2 text-sm text-muted-foreground">
                    {h.preview.startsWith("$") ? (
                      <MathInline>{h.preview.slice(1, -1)}</MathInline>
                    ) : (
                      <RichText>{h.preview}</RichText>
                    )}
                  </div>
                </button>
              </li>
            ))}
          </ul>
        </div>
      </DialogContent>
    </Dialog>
  );
}

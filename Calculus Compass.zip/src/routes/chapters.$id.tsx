import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { ArrowLeft, BookOpen, FlaskConical, GraduationCap } from "lucide-react";
import { findChapter, chapters, type Chapter } from "@/data/chapters";
import { RichText } from "@/lib/math";
import { FormulaCard } from "@/components/FormulaCard";
import { GuidedExample } from "@/components/GuidedExample";
import { SeriesSandbox } from "@/components/sandbox/SeriesSandbox";
import { HessianSandbox } from "@/components/sandbox/HessianSandbox";
import { QuizView } from "@/components/QuizView";
import { useProgress } from "@/lib/progress";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/chapters/$id")({
  loader: ({ params }) => {
    const chapter = findChapter(params.id);
    if (!chapter) throw notFound();
    return chapter;
  },
  head: ({ loaderData }) => ({
    meta: loaderData
      ? [
          { title: `${loaderData.title} — Calculus Companion` },
          { name: "description", content: loaderData.summary },
          { property: "og:title", content: loaderData.title },
          { property: "og:description", content: loaderData.summary },
        ]
      : [],
  }),
  component: ChapterPage,
  notFoundComponent: () => (
    <div className="p-10 text-center text-muted-foreground">Chapter not found.</div>
  ),
});

type Tab = "theory" | "sandbox" | "quiz";

function ChapterPage() {
  const chapter = Route.useLoaderData() as Chapter;
  const [tab, setTab] = useState<Tab>("theory");
  const { setTheoryRead, masteryPct } = useProgress();

  useEffect(() => {
    if (tab === "theory") setTheoryRead(chapter.id);
  }, [tab, chapter.id, setTheoryRead]);

  const pct = masteryPct(chapter.id);

  return (
    <main className="mx-auto max-w-6xl px-4 py-8">
      <div className="mb-6">
        <Link
          to="/"
          className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground"
        >
          <ArrowLeft className="h-4 w-4" /> All chapters
        </Link>
        <div className="mt-3 flex flex-wrap items-baseline gap-3">
          <span className="font-mono text-xs text-muted-foreground">
            Ch. {String(chapter.number).padStart(2, "0")} · {chapter.part}
          </span>
          <span className="text-xs text-muted-foreground">{pct}% mastered</span>
        </div>
        <h1 className="mt-1 text-3xl font-semibold tracking-tight md:text-4xl">{chapter.title}</h1>
        <p className="mt-2 max-w-3xl text-muted-foreground">{chapter.summary}</p>
      </div>

      <div className="mb-6 flex gap-1 border-b border-border">
        <TabBtn active={tab === "theory"} onClick={() => setTab("theory")} icon={<BookOpen className="h-4 w-4" />}>
          Theory
        </TabBtn>
        <TabBtn active={tab === "sandbox"} onClick={() => setTab("sandbox")} icon={<FlaskConical className="h-4 w-4" />}>
          Practice sandbox
        </TabBtn>
        <TabBtn active={tab === "quiz"} onClick={() => setTab("quiz")} icon={<GraduationCap className="h-4 w-4" />}>
          Quiz
        </TabBtn>
      </div>

      {tab === "theory" && (
        <div className="grid gap-6 lg:grid-cols-[1fr_320px]">
          <dl className="divide-y divide-border rounded-lg border border-border bg-card">
            {chapter.blocks.map((b, i) => (
              <div key={i} className="grid gap-1 px-4 py-3 sm:grid-cols-[1fr_2fr] sm:gap-6 sm:py-4">
                <dt className="flex items-start gap-2">
                  <KindBadge kind={b.kind} />
                  <span className="font-semibold leading-snug">
                    <RichText>{b.title}</RichText>
                  </span>
                </dt>
                <dd className="text-sm leading-relaxed text-muted-foreground">
                  <RichText>{b.body}</RichText>
                </dd>
              </div>
            ))}
          </dl>
          <aside className="space-y-3 lg:sticky lg:top-20 lg:self-start">
            <h3 className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
              Formula cheat sheet
            </h3>
            {chapter.formulas.map((f) => (
              <FormulaCard key={f.id} formula={f} />
            ))}
          </aside>
        </div>
      )}

      {tab === "sandbox" && (
        <div className="grid gap-6 lg:grid-cols-2">
          <div className="space-y-4">
            <h3 className="text-sm font-semibold uppercase tracking-wide text-muted-foreground">
              Guided solutions
            </h3>
            {chapter.examples.map((ex, i) => (
              <GuidedExample key={i} example={ex} />
            ))}
          </div>
          <div className="space-y-4">
            <h3 className="text-sm font-semibold uppercase tracking-wide text-muted-foreground">
              Interactive sandbox
            </h3>
            {chapter.sandbox === "series" ? (
              <SeriesSandbox />
            ) : chapter.sandbox === "hessian" ? (
              <HessianSandbox />
            ) : (
              <div className="rounded-lg border border-dashed border-border p-6 text-center text-sm text-muted-foreground">
                No interactive simulator for this chapter — try the{" "}
                <Link to="/chapters/$id" params={{ id: "sequences-series" }} className="underline">
                  series convergence
                </Link>{" "}
                or{" "}
                <Link to="/chapters/$id" params={{ id: "extrema" }} className="underline">
                  Hessian classifier
                </Link>{" "}
                sandbox.
              </div>
            )}
          </div>
        </div>
      )}

      {tab === "quiz" && (
        <div className="max-w-3xl">
          <QuizView chapterId={chapter.id} quiz={chapter.quiz} />
        </div>
      )}

      <div className="mt-12 flex justify-between border-t border-border pt-6">
        <ChapterNav id={chapter.id} dir={-1} />
        <ChapterNav id={chapter.id} dir={1} />
      </div>
    </main>
  );
}

function TabBtn({
  active,
  onClick,
  children,
  icon,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
  icon: React.ReactNode;
}) {
  return (
    <button
      onClick={onClick}
      className={
        "flex items-center gap-2 border-b-2 px-4 py-2.5 text-sm font-medium transition -mb-px " +
        (active
          ? "border-foreground text-foreground"
          : "border-transparent text-muted-foreground hover:text-foreground")
      }
    >
      {icon}
      {children}
    </button>
  );
}

function KindBadge({ kind }: { kind: string }) {
  const map: Record<string, string> = {
    definition: "bg-blue-500/10 text-blue-700 dark:text-blue-300",
    theorem: "bg-emerald-500/10 text-emerald-700 dark:text-emerald-300",
    proof: "bg-amber-500/10 text-amber-700 dark:text-amber-300",
    note: "bg-secondary text-muted-foreground",
  };
  return (
    <span className={`rounded px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-wide ${map[kind] ?? ""}`}>
      {kind}
    </span>
  );
}

function ChapterNav({ id, dir }: { id: string; dir: -1 | 1 }) {
  const idx = chapters.findIndex((c) => c.id === id);
  const target = chapters[idx + dir];
  if (!target) return <span />;
  return (
    <Button asChild variant="ghost">
      <Link to="/chapters/$id" params={{ id: target.id }}>
        {dir === -1 ? "← " : ""}
        Ch. {target.number}: {target.title}
        {dir === 1 ? " →" : ""}
      </Link>
    </Button>
  );
}

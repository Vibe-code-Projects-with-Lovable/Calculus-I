import { createContext, useCallback, useContext, useEffect, useState } from "react";

type Progress = Record<string, { theoryRead?: boolean; quizScore?: number; quizTotal?: number }>;

const KEY = "calc-companion-progress";

const Ctx = createContext<{
  progress: Progress;
  setTheoryRead: (id: string) => void;
  setQuizScore: (id: string, score: number, total: number) => void;
  masteryPct: (id: string) => number;
}>({
  progress: {},
  setTheoryRead: () => {},
  setQuizScore: () => {},
  masteryPct: () => 0,
});

export function ProgressProvider({ children }: { children: React.ReactNode }) {
  const [progress, setProgress] = useState<Progress>({});

  useEffect(() => {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) setProgress(JSON.parse(raw));
    } catch {}
  }, []);

  const persist = (p: Progress) => {
    setProgress(p);
    try {
      localStorage.setItem(KEY, JSON.stringify(p));
    } catch {}
  };

  const setTheoryRead = useCallback(
    (id: string) => {
      persist({ ...progress, [id]: { ...progress[id], theoryRead: true } });
    },
    [progress],
  );

  const setQuizScore = useCallback(
    (id: string, score: number, total: number) => {
      const prev = progress[id] ?? {};
      const best = Math.max(prev.quizScore ?? 0, score);
      persist({ ...progress, [id]: { ...prev, quizScore: best, quizTotal: total } });
    },
    [progress],
  );

  const masteryPct = useCallback(
    (id: string) => {
      const p = progress[id];
      if (!p) return 0;
      let pct = 0;
      if (p.theoryRead) pct += 30;
      if (p.quizTotal && p.quizScore !== undefined) {
        pct += Math.round((p.quizScore / p.quizTotal) * 70);
      }
      return Math.min(100, pct);
    },
    [progress],
  );

  return (
    <Ctx.Provider value={{ progress, setTheoryRead, setQuizScore, masteryPct }}>
      {children}
    </Ctx.Provider>
  );
}

export const useProgress = () => useContext(Ctx);

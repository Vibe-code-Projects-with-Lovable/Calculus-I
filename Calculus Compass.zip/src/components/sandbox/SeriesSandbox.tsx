import { useMemo, useState } from "react";
import { Slider } from "@/components/ui/slider";
import { MathInline } from "@/lib/math";

export function SeriesSandbox() {
  const [z, setZ] = useState(0.6);
  const [n, setN] = useState(30);

  const partial = useMemo(() => {
    const arr: { i: number; s: number }[] = [];
    let s = 0;
    for (let i = 0; i <= n; i++) {
      s += Math.pow(z, i);
      arr.push({ i, s });
    }
    return arr;
  }, [z, n]);

  const limit = Math.abs(z) < 1 ? 1 / (1 - z) : null;

  const W = 460;
  const H = 200;
  const pad = 28;
  const ys = partial.map((p) => p.s);
  const minY = Math.min(...ys, limit ?? 0) - 0.5;
  const maxY = Math.max(...ys, limit ?? 1) + 0.5;
  const sx = (i: number) => pad + ((W - 2 * pad) * i) / Math.max(1, n);
  const sy = (v: number) => H - pad - ((H - 2 * pad) * (v - minY)) / (maxY - minY);

  const path = partial.map((p, idx) => `${idx === 0 ? "M" : "L"} ${sx(p.i)} ${sy(p.s)}`).join(" ");

  return (
    <div className="space-y-4">
      <div className="rounded-lg border border-border bg-card p-4">
        <p className="text-sm text-muted-foreground">
          Geometric series <MathInline>{`S_n = \\sum_{k=0}^{n} z^k`}</MathInline>. Drag the sliders
          and watch the partial sums.
        </p>
        <div className="mt-4 grid gap-4 sm:grid-cols-2">
          <div>
            <div className="mb-1 flex justify-between text-xs">
              <span>z = {z.toFixed(2)}</span>
              <span className="text-muted-foreground">(-1.5 … 1.5)</span>
            </div>
            <Slider
              value={[z]}
              min={-1.5}
              max={1.5}
              step={0.01}
              onValueChange={(v) => setZ(v[0])}
            />
          </div>
          <div>
            <div className="mb-1 flex justify-between text-xs">
              <span>n = {n}</span>
              <span className="text-muted-foreground">(1 … 100)</span>
            </div>
            <Slider value={[n]} min={1} max={100} step={1} onValueChange={(v) => setN(v[0])} />
          </div>
        </div>
      </div>

      <div className="rounded-lg border border-border bg-card p-3">
        <svg viewBox={`0 0 ${W} ${H}`} className="w-full">
          <line
            x1={pad}
            y1={H - pad}
            x2={W - pad}
            y2={H - pad}
            stroke="currentColor"
            strokeOpacity={0.2}
          />
          <line x1={pad} y1={pad} x2={pad} y2={H - pad} stroke="currentColor" strokeOpacity={0.2} />
          {limit !== null && (
            <line
              x1={pad}
              y1={sy(limit)}
              x2={W - pad}
              y2={sy(limit)}
              stroke="hsl(var(--primary, 220 90% 56%))"
              strokeDasharray="4 4"
              strokeOpacity={0.5}
            />
          )}
          <path d={path} fill="none" stroke="currentColor" strokeWidth={1.5} />
          {partial.map((p) => (
            <circle key={p.i} cx={sx(p.i)} cy={sy(p.s)} r={1.8} fill="currentColor" />
          ))}
        </svg>
      </div>

      <div className="rounded-lg border border-border bg-secondary/40 p-3 text-sm">
        {limit !== null ? (
          <>
            Converges to <MathInline>{`\\frac{1}{1-z} = ${limit.toFixed(4)}`}</MathInline>. Current
            partial sum: <span className="font-mono">{partial[n].s.toFixed(4)}</span>.
          </>
        ) : (
          <>
            <span className="font-medium text-destructive">Diverges</span>: |z| ≥ 1, so the general
            term does not tend to 0.
          </>
        )}
      </div>
    </div>
  );
}

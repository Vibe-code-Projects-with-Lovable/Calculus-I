import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { RichText } from "@/lib/math";
import { CheckCircle2, XCircle } from "lucide-react";
import type { Quiz } from "@/data/chapters";
import { useProgress } from "@/lib/progress";

function normalize(s: string) {
  return s.trim().toLowerCase().replace(/\s+/g, "").replace(/\*/g, "");
}

export function QuizView({ chapterId, quiz }: { chapterId: string; quiz: Quiz[] }) {
  const [answers, setAnswers] = useState<Record<string, string | number>>({});
  const [submitted, setSubmitted] = useState(false);
  const { setQuizScore } = useProgress();

  const isCorrect = (q: Quiz) => {
    const a = answers[q.id];
    if (a === undefined) return false;
    if (q.kind === "mcq") return a === q.answer;
    const norm = normalize(String(a));
    if (norm === normalize(q.answer)) return true;
    return (q.accepts ?? []).some((alt) => normalize(alt) === norm);
  };

  const score = quiz.reduce((acc, q) => acc + (isCorrect(q) ? 1 : 0), 0);

  const submit = () => {
    setSubmitted(true);
    setQuizScore(chapterId, score, quiz.length);
  };

  const reset = () => {
    setAnswers({});
    setSubmitted(false);
  };

  return (
    <div className="space-y-6">
      {quiz.map((q, idx) => {
        const correct = isCorrect(q);
        return (
          <div
            key={q.id}
            className={
              "rounded-lg border bg-card p-4 " +
              (submitted
                ? correct
                  ? "border-emerald-500/40"
                  : "border-destructive/40"
                : "border-border")
            }
          >
            <div className="mb-3 flex items-start gap-3">
              <span className="mt-0.5 inline-flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-secondary text-xs font-medium">
                {idx + 1}
              </span>
              <div className="text-sm font-medium">
                <RichText>{q.prompt}</RichText>
              </div>
            </div>

            {q.kind === "mcq" ? (
              <div className="ml-9 space-y-2">
                {q.choices.map((c, i) => {
                  const picked = answers[q.id] === i;
                  return (
                    <label
                      key={i}
                      className={
                        "flex cursor-pointer items-start gap-2 rounded-md border border-border px-3 py-2 text-sm " +
                        (picked ? "bg-secondary" : "hover:bg-muted/60") +
                        (submitted && i === q.answer ? " border-emerald-500/60" : "")
                      }
                    >
                      <input
                        type="radio"
                        name={q.id}
                        className="mt-1"
                        checked={picked}
                        disabled={submitted}
                        onChange={() => setAnswers((a) => ({ ...a, [q.id]: i }))}
                      />
                      <RichText>{c}</RichText>
                    </label>
                  );
                })}
              </div>
            ) : (
              <div className="ml-9">
                <Input
                  placeholder="Your answer"
                  value={(answers[q.id] as string) ?? ""}
                  disabled={submitted}
                  onChange={(e) => setAnswers((a) => ({ ...a, [q.id]: e.target.value }))}
                />
              </div>
            )}

            {submitted && (
              <div
                className={
                  "ml-9 mt-3 flex gap-2 rounded-md p-3 text-sm " +
                  (correct
                    ? "bg-emerald-500/10 text-emerald-900 dark:text-emerald-200"
                    : "bg-destructive/10 text-destructive-foreground")
                }
              >
                {correct ? (
                  <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-600" />
                ) : (
                  <XCircle className="h-4 w-4 shrink-0 text-destructive" />
                )}
                <div>
                  <div className="font-medium">
                    {correct ? "Correct." : "Not quite."}{" "}
                    {!correct && q.kind === "input" && (
                      <>Expected: <span className="font-mono">{q.answer}</span></>
                    )}
                  </div>
                  <div className="mt-1 text-foreground/80">
                    <RichText>{q.explanation}</RichText>
                  </div>
                </div>
              </div>
            )}
          </div>
        );
      })}

      <div className="flex items-center gap-3">
        {!submitted ? (
          <Button onClick={submit} disabled={Object.keys(answers).length === 0}>
            Submit answers
          </Button>
        ) : (
          <>
            <Button variant="outline" onClick={reset}>
              Try again
            </Button>
            <span className="text-sm text-muted-foreground">
              Score: <span className="font-semibold text-foreground">{score}</span> / {quiz.length}
            </span>
          </>
        )}
      </div>
    </div>
  );
}

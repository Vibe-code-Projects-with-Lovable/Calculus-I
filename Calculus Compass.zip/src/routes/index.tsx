import { createFileRoute, Link } from "@tanstack/react-router";
import { chapters } from "@/data/chapters";
import { useProgress } from "@/lib/progress";
import { ArrowRight, BookOpen, Sparkles } from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Calculus Companion — Master Analysis I & II" },
      {
        name: "description",
        content:
          "Ten-chapter interactive course covering sequences, Taylor formulas, Lebesgue integration, Fourier series, and vector calculus.",
      },
    ],
  }),
  component: Dashboard,
});

function Dashboard() {
  const { masteryPct } = useProgress();
  const partI = chapters.filter((c) => c.part === "Analysis I");
  const partII = chapters.filter((c) => c.part === "Analysis II");

  const total = chapters.reduce((s, c) => s + masteryPct(c.id), 0);
  const overall = Math.round(total / chapters.length);

  return (
    <main className="mx-auto max-w-6xl px-4 py-10">
      <section className="mb-12 grid gap-8 md:grid-cols-[1fr_auto] md:items-end">
        <div>
          <span className="inline-flex items-center gap-1.5 rounded-full border border-border bg-secondary px-3 py-1 text-xs font-medium text-muted-foreground">
            <Sparkles className="h-3 w-3" /> Mathematical Analysis curriculum
          </span>
          <h1 className="mt-4 text-4xl font-semibold tracking-tight md:text-5xl">
            Master Analysis I & II,
            <br className="hidden md:block" />
            <span className="text-muted-foreground">one chapter at a time.</span>
          </h1>
          <p className="mt-4 max-w-xl text-base text-muted-foreground">
            Ten focused chapters with curated lecture notes, formula cheat sheets, hands-on
            sandboxes and step-by-step worked solutions. Built for university coursework.
          </p>
        </div>
        <div className="rounded-xl border border-border bg-card p-5">
          <div className="text-xs uppercase tracking-wide text-muted-foreground">
            Overall mastery
          </div>
          <div className="mt-1 text-3xl font-semibold">{overall}%</div>
          <div className="mt-3 h-1.5 w-40 overflow-hidden rounded-full bg-secondary">
            <div className="h-full bg-primary" style={{ width: `${overall}%` }} />
          </div>
          <Link
            to="/exam"
            className="mt-4 inline-flex items-center gap-1.5 text-sm font-medium text-primary hover:underline"
          >
            Start the full exam <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </section>

      <Section title="Analysis I" subtitle="Foundations of real and functional analysis">
        {partI.map((c) => (
          <ChapterCard key={c.id} c={c} pct={masteryPct(c.id)} />
        ))}
      </Section>

      <Section title="Analysis II" subtitle="Multivariable, measure, Fourier, and vector calculus">
        {partII.map((c) => (
          <ChapterCard key={c.id} c={c} pct={masteryPct(c.id)} />
        ))}
      </Section>
    </main>
  );
}

function Section({
  title,
  subtitle,
  children,
}: {
  title: string;
  subtitle: string;
  children: React.ReactNode;
}) {
  return (
    <section className="mb-12">
      <div className="mb-4 flex items-baseline justify-between border-b border-border pb-2">
        <h2 className="text-lg font-semibold tracking-tight">{title}</h2>
        <span className="text-xs text-muted-foreground">{subtitle}</span>
      </div>
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">{children}</div>
    </section>
  );
}

function ChapterCard({ c, pct }: { c: (typeof chapters)[number]; pct: number }) {
  return (
    <Link
      to="/chapters/$id"
      params={{ id: c.id }}
      className="group flex flex-col rounded-xl border border-border bg-card p-5 transition hover:border-foreground/20 hover:shadow-sm"
    >
      <div className="flex items-start justify-between">
        <span className="text-xs font-mono text-muted-foreground">
          Chapter {String(c.number).padStart(2, "0")}
        </span>
        <BookOpen className="h-4 w-4 text-muted-foreground transition group-hover:text-foreground" />
      </div>
      <h3 className="mt-2 text-base font-semibold leading-snug">{c.title}</h3>
      <p className="mt-1 line-clamp-2 text-sm text-muted-foreground">{c.summary}</p>
      <div className="mt-auto pt-4">
        <div className="mb-1 flex items-center justify-between text-xs text-muted-foreground">
          <span>{pct}% mastered</span>
          <span>
            {c.blocks.length} notes · {c.formulas.length} formulas
          </span>
        </div>
        <div className="h-1 overflow-hidden rounded-full bg-secondary">
          <div className="h-full bg-primary" style={{ width: `${pct}%` }} />
        </div>
      </div>
    </Link>
  );
}

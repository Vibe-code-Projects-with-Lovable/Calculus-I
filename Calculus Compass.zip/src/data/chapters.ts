export type Block =
  | { kind: "definition"; title: string; body: string }
  | { kind: "theorem"; title: string; body: string }
  | { kind: "proof"; title: string; body: string }
  | { kind: "note"; title: string; body: string };

export type Formula = {
  id: string;
  name: string;
  latex: string;
  meaning: string;
};

export type Example = {
  title: string;
  statement: string;
  steps: string[];
};

export type Quiz =
  | {
      kind: "mcq";
      id: string;
      prompt: string;
      choices: string[];
      answer: number;
      explanation: string;
    }
  | {
      kind: "input";
      id: string;
      prompt: string;
      answer: string; // expected normalized string
      accepts?: string[]; // alternative accepted normalized strings
      explanation: string;
    };

export type Chapter = {
  id: string;
  number: number;
  title: string;
  part: "Analysis I" | "Analysis II";
  summary: string;
  blocks: Block[];
  formulas: Formula[];
  examples: Example[];
  sandbox?: "series" | "hessian";
  quiz: Quiz[];
};

export const chapters: Chapter[] = [
  {
    id: "sequences-series",
    number: 1,
    title: "Sequences and Series of Numbers",
    part: "Analysis I",
    summary:
      "Real numbers, bounds, Cauchy sequences, completeness, and convergence criteria for numerical series.",
    blocks: [
      { kind: "definition", title: "Supremum", body: "The least upper bound of a set $A \\subset \\mathbb{R}$." },
      { kind: "definition", title: "Infimum", body: "The greatest lower bound of a set $A \\subset \\mathbb{R}$." },
      { kind: "definition", title: "Cauchy sequence", body: "A sequence whose terms become arbitrarily close to each other: $|u_p - u_q| \\to 0$." },
      { kind: "theorem", title: "Completeness of $\\mathbb{R}$", body: "A real sequence converges if and only if it is Cauchy." },
      { kind: "theorem", title: "Monotone convergence", body: "Every monotone bounded sequence converges." },
      { kind: "theorem", title: "Ratio test (d'Alembert)", body: "If $|a_{n+1}/a_n| \\to \\ell$: converges for $\\ell<1$, diverges for $\\ell>1$." },
      { kind: "theorem", title: "Root test (Cauchy)", body: "If $\\sqrt[n]{|a_n|} \\to \\ell$: converges for $\\ell<1$, diverges for $\\ell>1$." },
      { kind: "theorem", title: "Raabe–Duhamel", body: "If $n(1 - a_{n+1}/a_n) \\to \\ell$: converges for $\\ell>1$, diverges for $\\ell<1$." },
      { kind: "theorem", title: "Leibniz criterion", body: "An alternating series with $|a_n|$ decreasing to $0$ converges." },
      { kind: "theorem", title: "Integral test", body: "For $f$ positive, decreasing on $[1,\\infty)$, $\\sum f(n)$ and $\\int_1^\\infty f$ share the same nature." },
      { kind: "proof", title: "Geometric series sum", body: "For $|q|<1$: $S_n = \\frac{1-q^{n+1}}{1-q} \\to \\frac{1}{1-q}$." },
    ],
    formulas: [
      {
        id: "geom",
        name: "Geometric series",
        latex: "\\sum_{n=0}^{\\infty} q^n = \\frac{1}{1-q}, \\quad |q| < 1",
        meaning: "Closed form of a convergent geometric series; foundational benchmark for comparison tests.",
      },
      {
        id: "riemann",
        name: "Riemann (p-series)",
        latex: "\\sum_{n \\ge 1} \\frac{1}{n^{\\alpha}} \\text{ converges} \\iff \\alpha > 1",
        meaning: "Reference series that calibrates the comparison and integral tests.",
      },
      {
        id: "dalembert",
        name: "Ratio test",
        latex: "\\lim_{n\\to\\infty} \\left| \\frac{a_{n+1}}{a_n} \\right| = \\ell",
        meaning: "$\\ell < 1$ implies absolute convergence; $\\ell > 1$ implies divergence.",
      },
      {
        id: "cauchy-root",
        name: "Root test",
        latex: "\\lim_{n\\to\\infty} \\sqrt[n]{|a_n|} = \\ell",
        meaning: "Same dichotomy as the ratio test, often stronger.",
      },
    ],
    examples: [
      {
        title: "Nature of $\\sum \\frac{n!}{n^n}$",
        statement: "Determine whether the series $\\sum_{n\\ge 1} \\frac{n!}{n^n}$ converges.",
        steps: [
          "Apply the ratio test with $a_n = n!/n^n$.",
          "Compute $\\dfrac{a_{n+1}}{a_n} = \\dfrac{(n+1)!}{(n+1)^{n+1}} \\cdot \\dfrac{n^n}{n!} = \\dfrac{n^n}{(n+1)^n} = \\left(\\dfrac{n}{n+1}\\right)^n$.",
          "Take the limit: $\\left(\\dfrac{n}{n+1}\\right)^n \\to \\dfrac{1}{e}$.",
          "Since $\\dfrac{1}{e} < 1$, the ratio test guarantees the series converges.",
        ],
      },
    ],
    sandbox: "series",
    quiz: [
      {
        kind: "mcq",
        id: "q1",
        prompt: "If a real sequence $(u_n)$ is monotone and bounded, then it is:",
        choices: ["divergent", "convergent", "Cauchy but not convergent", "unbounded"],
        answer: 1,
        explanation:
          "The monotone convergence theorem states every monotone bounded real sequence converges to its supremum (if increasing) or infimum (if decreasing).",
      },
      {
        kind: "mcq",
        id: "q2",
        prompt: "The series $\\sum 1/n^{\\alpha}$ converges if and only if:",
        choices: ["$\\alpha \\le 1$", "$\\alpha > 1$", "$\\alpha \\ge 0$", "always"],
        answer: 1,
        explanation:
          "By the integral test, $\\int_1^\\infty x^{-\\alpha}\\,dx$ converges iff $\\alpha > 1$.",
      },
      {
        kind: "input",
        id: "q3",
        prompt: "Compute $\\displaystyle \\sum_{n=0}^{\\infty} (1/2)^n$. Enter a number.",
        answer: "2",
        explanation: "Geometric series with $q = 1/2$: sum equals $1/(1-1/2) = 2$.",
      },
    ],
  },
  {
    id: "metric-spaces",
    number: 2,
    title: "Metric and Normed Spaces",
    part: "Analysis I",
    summary:
      "Distances, open and closed balls, compactness, normed vector spaces, Banach spaces and linear operators.",
    blocks: [
      { kind: "definition", title: "Metric space", body: "A set $X$ with a distance $d$ satisfying separation, symmetry, and the triangle inequality." },
      { kind: "definition", title: "Open ball", body: "$B(x_0, r) = \\{ x : d(x, x_0) < r \\}$." },
      { kind: "definition", title: "Closed ball", body: "$\\overline{B}(x_0, r) = \\{ x : d(x, x_0) \\le r \\}$." },
      { kind: "definition", title: "Norm", body: "A length function $\\|\\cdot\\|$ on a vector space inducing the distance $d(x,y) = \\|x-y\\|$." },
      { kind: "definition", title: "Banach space", body: "A normed vector space that is complete (every Cauchy sequence converges)." },
      { kind: "theorem", title: "Bolzano–Weierstrass", body: "In a compact metric space every sequence has a convergent subsequence." },
      { kind: "theorem", title: "Heine–Borel", body: "In a finite-dimensional normed space, compact = closed and bounded." },
      { kind: "definition", title: "Linear operator", body: "A linear map $T : E \\to F$ between normed spaces; bounded $\\iff$ continuous." },
      { kind: "definition", title: "Spectrum", body: "$\\sigma(T) = \\{\\lambda : T - \\lambda I \\text{ is not invertible}\\}$ — generalises eigenvalues." },
    ],
    formulas: [
      {
        id: "norm-axioms",
        name: "Norm axioms",
        latex: "\\|x\\| = 0 \\iff x = 0, \\ \\|\\lambda x\\| = |\\lambda|\\,\\|x\\|, \\ \\|x+y\\| \\le \\|x\\| + \\|y\\|",
        meaning: "Defines a length on a vector space, inducing the metric $d(x,y) = \\|x-y\\|$.",
      },
      {
        id: "operator-norm",
        name: "Operator norm",
        latex: "\\|T\\|_{op} = \\sup_{\\|x\\| \\le 1} \\|Tx\\|",
        meaning: "Smallest constant such that $\\|Tx\\| \\le \\|T\\|_{op}\\|x\\|$; finite iff $T$ is continuous.",
      },
      {
        id: "spectrum",
        name: "Spectrum",
        latex: "\\sigma(T) = \\{\\lambda \\in \\mathbb{C} : T - \\lambda I \\text{ is not invertible}\\}",
        meaning: "Generalisation of eigenvalues to bounded operators on Banach spaces.",
      },
    ],
    examples: [
      {
        title: "Equivalent norms on $\\mathbb{R}^n$",
        statement: "Show that $\\|\\cdot\\|_1$, $\\|\\cdot\\|_2$ and $\\|\\cdot\\|_\\infty$ are equivalent on $\\mathbb{R}^n$.",
        steps: [
          "Recall $\\|x\\|_\\infty \\le \\|x\\|_2 \\le \\|x\\|_1$ by definition.",
          "Conversely $\\|x\\|_1 \\le n\\,\\|x\\|_\\infty$ and $\\|x\\|_2 \\le \\sqrt{n}\\,\\|x\\|_\\infty$.",
          "All three norms induce the same topology and the same notion of convergence.",
        ],
      },
    ],
    quiz: [
      {
        kind: "mcq",
        id: "q1",
        prompt: "A complete normed vector space is called:",
        choices: ["Hilbert space", "Banach space", "Frechet space", "Pre-Hilbert space"],
        answer: 1,
        explanation: "By definition a Banach space is a normed vector space that is complete for its norm-induced metric.",
      },
      {
        kind: "mcq",
        id: "q2",
        prompt: "In a finite-dimensional normed space, compact subsets are exactly:",
        choices: [
          "open subsets",
          "closed and bounded subsets",
          "convex subsets",
          "countable subsets",
        ],
        answer: 1,
        explanation: "This is the Heine–Borel theorem, valid in any finite-dimensional normed space.",
      },
    ],
  },
  {
    id: "function-series",
    number: 3,
    title: "Sequences and Series of Functions",
    part: "Analysis I",
    summary:
      "Pointwise vs. uniform convergence, transfer of continuity, power series and radius of convergence.",
    blocks: [
      { kind: "definition", title: "Pointwise convergence", body: "$f_n(x) \\to f(x)$ at each $x$ separately." },
      { kind: "definition", title: "Uniform convergence", body: "$\\sup_x |f_n(x) - f(x)| \\to 0$ — same rate everywhere." },
      { kind: "theorem", title: "Continuity transfer", body: "Uniform limit of continuous functions is continuous." },
      { kind: "theorem", title: "Term-by-term integration", body: "Uniform convergence on $[a,b]$ lets you swap $\\int$ and $\\lim$." },
      { kind: "theorem", title: "Term-by-term differentiation", body: "Allowed when $(f_n')$ converges uniformly and $(f_n)$ converges at one point." },
      { kind: "definition", title: "Power series", body: "$\\sum a_n z^n$ — a series whose terms are monomials in $z$." },
      { kind: "theorem", title: "Abel's theorem", body: "Every power series has a radius $R$: converges absolutely for $|z|<R$, diverges for $|z|>R$." },
      { kind: "theorem", title: "Weierstrass M-test", body: "If $|f_n(x)| \\le M_n$ and $\\sum M_n < \\infty$, then $\\sum f_n$ converges uniformly." },
    ],
    formulas: [
      {
        id: "cauchy-hadamard",
        name: "Cauchy–Hadamard",
        latex: "\\frac{1}{R} = \\limsup_{n\\to\\infty} \\sqrt[n]{|a_n|}",
        meaning: "Computes the radius of convergence of a power series.",
      },
      {
        id: "uniform-bound",
        name: "Weierstrass M-test",
        latex: "|f_n(x)| \\le M_n,\\ \\sum M_n < \\infty \\implies \\sum f_n \\text{ converges uniformly}",
        meaning: "Reduces uniform convergence of a function series to convergence of a numerical series.",
      },
    ],
    examples: [
      {
        title: "Radius of $\\sum z^n / n$",
        statement: "Find the radius of convergence of $\\sum_{n\\ge 1} z^n / n$.",
        steps: [
          "Take $a_n = 1/n$.",
          "Then $\\sqrt[n]{|a_n|} = n^{-1/n} \\to 1$.",
          "By Cauchy–Hadamard, $R = 1$.",
        ],
      },
    ],
    quiz: [
      {
        kind: "input",
        id: "q1",
        prompt: "Radius of convergence of $\\sum_{n\\ge 0} z^n / n!$. Enter $\\infty$ as 'inf'.",
        answer: "inf",
        explanation: "Ratio test: $(n!)/((n+1)!) = 1/(n+1) \\to 0$, so $R = \\infty$.",
      },
      {
        kind: "mcq",
        id: "q2",
        prompt: "Uniform convergence preserves:",
        choices: ["only boundedness", "continuity", "differentiability automatically", "nothing"],
        answer: 1,
        explanation: "Continuity transfers under uniform convergence; differentiability requires extra hypotheses on $(f_n')$.",
      },
    ],
  },
  {
    id: "taylor",
    number: 4,
    title: "Taylor Formulas",
    part: "Analysis I",
    summary:
      "Taylor–Lagrange and Taylor–Young formulas, Landau symbols, classical expansions, and extrema.",
    blocks: [
      { kind: "theorem", title: "Taylor–Lagrange", body: "$f(b) = \\sum_{k=0}^n \\frac{(b-a)^k}{k!} f^{(k)}(a) + \\frac{(b-a)^{n+1}}{(n+1)!} f^{(n+1)}(c)$ for some $c \\in (a,b)$." },
      { kind: "theorem", title: "Taylor–Young", body: "Near $a$: $f(a+h) = \\sum_{k=0}^n \\frac{h^k}{k!} f^{(k)}(a) + o(h^n)$." },
      { kind: "definition", title: "Big O", body: "$f = O(g)$ means $|f/g|$ stays bounded near the point." },
      { kind: "definition", title: "small o", body: "$f = o(g)$ means $f/g \\to 0$ — strictly negligible." },
      { kind: "definition", title: "Taylor series", body: "Power series $\\sum \\frac{f^{(n)}(a)}{n!}(x-a)^n$ associated to a smooth $f$." },
      { kind: "theorem", title: "Extrema criterion", body: "At a critical point, the sign of the first non-zero $f^{(k)}(a)$ classifies it." },
    ],
    formulas: [
      {
        id: "exp",
        name: "Expansion of $e^x$",
        latex: "e^x = \\sum_{n=0}^{\\infty} \\frac{x^n}{n!}",
        meaning: "Globally valid expansion (radius of convergence $\\infty$).",
      },
      {
        id: "log",
        name: "Expansion of $\\ln(1+x)$",
        latex: "\\ln(1+x) = \\sum_{n=1}^{\\infty} \\frac{(-1)^{n+1} x^n}{n}, \\ |x| < 1",
        meaning: "Alternating series valid on $(-1, 1]$.",
      },
      {
        id: "sin",
        name: "Expansion of $\\sin x$",
        latex: "\\sin x = \\sum_{n=0}^{\\infty} \\frac{(-1)^n x^{2n+1}}{(2n+1)!}",
        meaning: "Entire function; expansion is valid everywhere.",
      },
    ],
    examples: [
      {
        title: "Limit via Taylor–Young",
        statement: "Compute $\\displaystyle \\lim_{x\\to 0} \\frac{\\sin x - x}{x^3}$.",
        steps: [
          "Use Taylor–Young: $\\sin x = x - x^3/6 + o(x^3)$.",
          "Thus $\\sin x - x = -x^3/6 + o(x^3)$.",
          "Divide by $x^3$: $\\dfrac{\\sin x - x}{x^3} = -\\dfrac{1}{6} + o(1) \\to -\\dfrac{1}{6}$.",
        ],
      },
    ],
    quiz: [
      {
        kind: "input",
        id: "q1",
        prompt: "Value of $\\lim_{x\\to 0} (1 - \\cos x)/x^2$. Enter a fraction like 1/2.",
        answer: "1/2",
        explanation: "$\\cos x = 1 - x^2/2 + o(x^2)$, so $(1-\\cos x)/x^2 \\to 1/2$.",
      },
      {
        kind: "mcq",
        id: "q2",
        prompt: "The remainder in the Taylor–Young formula at order $n$ is:",
        choices: ["$O(h^n)$", "$o(h^n)$", "$O(h^{n+1})$", "exactly zero"],
        answer: 1,
        explanation: "Taylor–Young gives a small-$o$ remainder; Taylor–Lagrange provides an explicit one of order $n+1$.",
      },
    ],
  },
  {
    id: "diff-multi",
    number: 5,
    title: "Differential Calculus of Several Variables",
    part: "Analysis II",
    summary:
      "Partial and directional derivatives, gradient, Jacobian, chain rule, Schwarz's theorem.",
    blocks: [
      { kind: "definition", title: "Partial derivative", body: "Derivative along one axis: $\\partial f/\\partial x_i$ varies $x_i$ alone." },
      { kind: "definition", title: "Directional derivative", body: "$D_v f(a) = \\nabla f(a) \\cdot v$ — rate of change in direction $v$." },
      { kind: "definition", title: "Gradient", body: "Vector $\\nabla f$ of all partial derivatives; points to steepest ascent." },
      { kind: "definition", title: "Differential", body: "Linear map $df_a$ such that $f(a+h) = f(a) + df_a(h) + o(\\|h\\|)$." },
      { kind: "definition", title: "Jacobian matrix", body: "Matrix $(\\partial f_i / \\partial x_j)$ of the differential of a vector-valued map." },
      { kind: "theorem", title: "Chain rule", body: "$J_{f \\circ g}(a) = J_f(g(a))\\,J_g(a)$." },
      { kind: "theorem", title: "Schwarz's theorem", body: "For $\\mathcal{C}^2$ maps, mixed partials commute: $\\partial^2 f/\\partial x \\partial y = \\partial^2 f/\\partial y \\partial x$." },
    ],
    formulas: [
      {
        id: "gradient",
        name: "Gradient",
        latex: "\\nabla f = \\left( \\frac{\\partial f}{\\partial x_1}, \\dots, \\frac{\\partial f}{\\partial x_n} \\right)",
        meaning: "Vector pointing in the direction of steepest ascent.",
      },
      {
        id: "directional",
        name: "Directional derivative",
        latex: "D_v f(a) = \\nabla f(a) \\cdot v",
        meaning: "Rate of change of $f$ at $a$ along the unit direction $v$.",
      },
      {
        id: "jacobian",
        name: "Jacobian matrix",
        latex: "J_f(a) = \\left( \\frac{\\partial f_i}{\\partial x_j}(a) \\right)_{i,j}",
        meaning: "Matrix of the differential of a vector-valued map.",
      },
    ],
    examples: [
      {
        title: "Gradient of $f(x,y) = x^2 y$",
        statement: "Compute $\\nabla f$ for $f(x,y) = x^2 y$.",
        steps: [
          "$\\partial f / \\partial x = 2xy$.",
          "$\\partial f / \\partial y = x^2$.",
          "Therefore $\\nabla f(x,y) = (2xy,\\ x^2)$.",
        ],
      },
    ],
    quiz: [
      {
        kind: "mcq",
        id: "q1",
        prompt: "If $f$ is $\\mathcal{C}^2$, then $\\partial^2 f/(\\partial x \\partial y)$ equals:",
        choices: ["always 0", "$\\partial^2 f/(\\partial y \\partial x)$", "$\\nabla f$", "Jacobian"],
        answer: 1,
        explanation: "Schwarz's symmetry theorem applies to $\\mathcal{C}^2$ maps.",
      },
      {
        kind: "input",
        id: "q2",
        prompt: "For $f(x,y) = x^2 + y^2$, enter $\\nabla f(1,2)$ as a tuple a,b.",
        answer: "2,4",
        explanation: "$\\nabla f = (2x, 2y)$, so at $(1,2)$ the gradient is $(2, 4)$.",
      },
    ],
  },
  {
    id: "extrema",
    number: 6,
    title: "Local and Conditional Extrema",
    part: "Analysis II",
    summary:
      "Hessian classification, least squares, implicit functions, and Lagrange multipliers.",
    blocks: [
      { kind: "definition", title: "Critical point", body: "A point where $\\nabla f = 0$ — candidate for a local extremum." },
      { kind: "definition", title: "Hessian matrix", body: "Symmetric matrix $H = (\\partial^2 f / \\partial x_i \\partial x_j)$ of second derivatives." },
      { kind: "theorem", title: "2D classification", body: "With $r=f_{xx},\\ s=f_{xy},\\ t=f_{yy}$ and $\\Delta = rt - s^2$: $\\Delta>0,\\ r>0$ min; $\\Delta>0,\\ r<0$ max; $\\Delta<0$ saddle." },
      { kind: "theorem", title: "Definite forms", body: "$H$ positive definite $\\Rightarrow$ local min; negative definite $\\Rightarrow$ local max; indefinite $\\Rightarrow$ saddle." },
      { kind: "theorem", title: "Lagrange multipliers", body: "Constrained extrema on $\\{g=0\\}$ satisfy $\\nabla f = \\lambda \\nabla g$." },
      { kind: "theorem", title: "Implicit function theorem", body: "If $\\partial F/\\partial y \\neq 0$ at $(a,b)$, $F(x,y)=0$ defines $y = \\varphi(x)$ locally." },
      { kind: "definition", title: "Least squares", body: "Minimises $\\|Ax - b\\|^2$; solution $\\hat x = (A^\\top A)^{-1} A^\\top b$." },
    ],
    formulas: [
      {
        id: "hess",
        name: "Hessian discriminant",
        latex: "\\Delta = rt - s^2",
        meaning: "Sign classifies critical points of a $\\mathcal{C}^2$ function of two variables.",
      },
      {
        id: "lagrange",
        name: "Lagrange system",
        latex: "\\nabla f = \\lambda \\nabla g, \\quad g(x) = 0",
        meaning: "Necessary condition for constrained extrema.",
      },
      {
        id: "ls",
        name: "Least squares normal equations",
        latex: "A^\\top A\\, \\hat{x} = A^\\top b",
        meaning: "Closed-form solution of $\\min \\|Ax - b\\|^2$.",
      },
    ],
    examples: [
      {
        title: "Classify the critical point of $f(x,y) = x^2 + xy + y^2$",
        statement: "Find and classify the critical points of $f(x,y) = x^2 + xy + y^2$.",
        steps: [
          "Solve $\\nabla f = 0$: $2x + y = 0$ and $x + 2y = 0$, giving $(0,0)$.",
          "Compute $r = 2$, $s = 1$, $t = 2$.",
          "Then $\\Delta = rt - s^2 = 4 - 1 = 3 > 0$ and $r > 0$.",
          "Therefore $(0,0)$ is a strict local minimum.",
        ],
      },
    ],
    sandbox: "hessian",
    quiz: [
      {
        kind: "mcq",
        id: "q1",
        prompt: "If $rt - s^2 < 0$ at a critical point, it is:",
        choices: ["local min", "local max", "saddle point", "inconclusive"],
        answer: 2,
        explanation: "Negative discriminant always indicates a saddle.",
      },
      {
        kind: "input",
        id: "q2",
        prompt: "For $f(x,y) = x^2 + xy + y^2$ at $(0,0)$, enter the discriminant $rt - s^2$.",
        answer: "3",
        explanation: "$r=2,\\ s=1,\\ t=2 \\Rightarrow \\Delta = 4 - 1 = 3$.",
      },
    ],
  },
  {
    id: "lebesgue",
    number: 7,
    title: "Measure Theory & Lebesgue Integration",
    part: "Analysis II",
    summary:
      "σ-algebras, measurable functions, Lebesgue measure and integral, convergence theorems.",
    blocks: [
      { kind: "definition", title: "σ-algebra", body: "Family of subsets closed under complement and countable unions — the “measurable” sets." },
      { kind: "definition", title: "Measure", body: "Map $\\mu : \\mathcal{A} \\to [0,\\infty]$ that is countably additive on disjoint unions." },
      { kind: "definition", title: "Lebesgue measure", body: "Unique measure on $\\mathbb{R}^n$ extending volume of boxes." },
      { kind: "definition", title: "Measurable function", body: "$f$ such that preimages of Borel sets are measurable." },
      { kind: "definition", title: "Lebesgue integral", body: "Built by approximating $f \\ge 0$ from below with simple functions." },
      { kind: "theorem", title: "Monotone convergence", body: "If $0 \\le f_n \\nearrow f$, then $\\int f_n \\to \\int f$." },
      { kind: "theorem", title: "Dominated convergence", body: "If $f_n \\to f$ a.e. and $|f_n| \\le g \\in L^1$, then $\\int f_n \\to \\int f$." },
      { kind: "theorem", title: "Fatou's lemma", body: "$\\int \\liminf f_n \\le \\liminf \\int f_n$ for $f_n \\ge 0$." },
      { kind: "note", title: "Lebesgue vs. Riemann", body: "Lebesgue integrates more functions and behaves better under limits." },
    ],
    formulas: [
      {
        id: "lebesgue-int",
        name: "Lebesgue integral of a simple function",
        latex: "\\int \\sum_{k=1}^n a_k \\mathbf{1}_{A_k}\\,d\\mu = \\sum_{k=1}^n a_k\\,\\mu(A_k)",
        meaning: "Definition of the integral, then extended by monotone limits.",
      },
      {
        id: "fatou",
        name: "Fatou's lemma",
        latex: "\\int \\liminf f_n \\,d\\mu \\le \\liminf \\int f_n \\,d\\mu",
        meaning: "Pointwise inequality for non-negative measurable sequences.",
      },
    ],
    examples: [
      {
        title: "Interchanging limit and integral",
        statement: "Show $\\int_0^1 \\dfrac{n x^{n-1}}{1 + x} \\, dx \\to 1/2$.",
        steps: [
          "Set $f_n(x) = n x^{n-1}/(1+x)$ on $(0,1)$.",
          "Use dominated convergence: $|f_n(x)| \\le n x^{n-1}$, but better integrate by parts.",
          "$\\int_0^1 f_n = \\left[\\dfrac{x^n}{1+x}\\right]_0^1 + \\int_0^1 \\dfrac{x^n}{(1+x)^2}\\,dx \\to \\dfrac{1}{2}$ since the second integral vanishes.",
        ],
      },
    ],
    quiz: [
      {
        kind: "mcq",
        id: "q1",
        prompt: "Lebesgue integrable functions form which kind of space?",
        choices: ["a finite set", "a Banach space $L^1$", "an unbounded set without norm", "only finite-dimensional"],
        answer: 1,
        explanation: "$L^1(\\mu)$ equipped with $\\|f\\|_1 = \\int |f| \\, d\\mu$ is a Banach space (after quotienting by a.e. equality).",
      },
      {
        kind: "mcq",
        id: "q2",
        prompt: "The dominated convergence theorem requires:",
        choices: [
          "an integrable dominating function $g$",
          "uniform convergence",
          "monotone sequences only",
          "continuity",
        ],
        answer: 0,
        explanation: "The hypothesis is $|f_n| \\le g$ with $g \\in L^1$ plus pointwise a.e. convergence.",
      },
    ],
  },
  {
    id: "hilbert-fourier",
    number: 8,
    title: "Hilbert Spaces & Fourier Series",
    part: "Analysis II",
    summary:
      "Inner products, orthonormal bases, classical Fourier series, Dirichlet's theorem, Fourier transform.",
    blocks: [
      { kind: "definition", title: "Inner product", body: "Bilinear, symmetric, positive-definite form $\\langle\\cdot,\\cdot\\rangle$ inducing $\\|x\\| = \\sqrt{\\langle x,x\\rangle}$." },
      { kind: "definition", title: "Hilbert space", body: "Inner-product space that is complete for the induced norm." },
      { kind: "theorem", title: "Orthogonal projection", body: "On a closed subspace $F$: every $x = p + q$ with $p \\in F$, $q \\perp F$, uniquely." },
      { kind: "definition", title: "Orthonormal basis", body: "Family $(e_n)$ with $\\langle e_i, e_j\\rangle = \\delta_{ij}$ whose span is dense." },
      { kind: "definition", title: "Fourier coefficients", body: "$c_n(f) = \\frac{1}{2\\pi}\\int_{-\\pi}^{\\pi} f(t) e^{-int}\\,dt$." },
      { kind: "theorem", title: "Dirichlet's theorem", body: "For piecewise $\\mathcal{C}^1$ periodic $f$, the Fourier series converges to $\\tfrac{1}{2}(f(x^+) + f(x^-))$." },
      { kind: "note", title: "Gibbs phenomenon", body: "Near a jump, partial Fourier sums overshoot by $\\approx 9\\%$." },
      { kind: "definition", title: "Fourier transform", body: "$\\hat f(\\xi) = \\int_\\mathbb{R} f(t) e^{-2i\\pi \\xi t}\\,dt$ — continuous analogue for $L^1$/$L^2$." },
    ],
    formulas: [
      {
        id: "fourier-coef",
        name: "Fourier coefficients",
        latex: "c_n(f) = \\frac{1}{2\\pi}\\int_{-\\pi}^{\\pi} f(t) e^{-int}\\,dt",
        meaning: "Projection of $f$ onto the orthonormal basis $(e^{int}/\\sqrt{2\\pi})_n$ of $L^2$.",
      },
      {
        id: "parseval",
        name: "Parseval's identity",
        latex: "\\frac{1}{2\\pi}\\int_{-\\pi}^{\\pi} |f|^2\\,dt = \\sum_{n\\in\\mathbb{Z}} |c_n(f)|^2",
        meaning: "Energy conservation in the Fourier basis.",
      },
      {
        id: "fourier-transform",
        name: "Fourier transform",
        latex: "\\hat{f}(\\xi) = \\int_{\\mathbb{R}} f(t) e^{-2i\\pi \\xi t}\\,dt",
        meaning: "Continuous analogue of Fourier series for $L^1$ (and extended to $L^2$).",
      },
    ],
    examples: [
      {
        title: "Fourier series of a square wave",
        statement: "Find the Fourier series of the $2\\pi$-periodic odd function with $f(x) = 1$ on $(0, \\pi)$ and $f(x) = -1$ on $(-\\pi, 0)$.",
        steps: [
          "Since $f$ is odd, all $a_n = 0$ and the series reduces to sines.",
          "$b_n = \\dfrac{2}{\\pi}\\int_0^\\pi \\sin(nx)\\,dx = \\dfrac{2}{n\\pi}(1 - \\cos n\\pi)$.",
          "Hence $b_n = 4/(n\\pi)$ for odd $n$ and $0$ otherwise.",
          "Therefore $f(x) = \\dfrac{4}{\\pi}\\sum_{k=0}^{\\infty} \\dfrac{\\sin((2k+1)x)}{2k+1}$.",
        ],
      },
    ],
    quiz: [
      {
        kind: "mcq",
        id: "q1",
        prompt: "Parseval's identity equates the $L^2$ norm of $f$ with:",
        choices: ["max $|c_n|$", "$\\sum |c_n|^2$", "$\\sum c_n$", "$\\sum |c_n|$"],
        answer: 1,
        explanation: "Parseval: $\\|f\\|_2^2 = \\sum_n |c_n|^2$ (with the appropriate normalisation).",
      },
      {
        kind: "mcq",
        id: "q2",
        prompt: "The Gibbs phenomenon occurs near:",
        choices: ["smooth points", "jump discontinuities", "zeros of $f$", "endpoints of $\\mathbb{R}$"],
        answer: 1,
        explanation: "Partial Fourier sums overshoot near jump discontinuities by a constant $\\approx 9\\%$.",
      },
    ],
  },
  {
    id: "multiple-int",
    number: 9,
    title: "Multiple Integrals",
    part: "Analysis II",
    summary:
      "Double and triple integrals, Fubini's theorem, change of variables, geometric and physical applications.",
    blocks: [
      { kind: "definition", title: "Double integral", body: "$\\iint_D f\\,dA$ — integral of $f$ over a planar region." },
      { kind: "definition", title: "Triple integral", body: "$\\iiint_V f\\,dV$ — integral over a solid region of $\\mathbb{R}^3$." },
      { kind: "theorem", title: "Fubini's theorem", body: "An integrable $f$ on $A \\times B$ can be integrated iteratively in either order." },
      { kind: "theorem", title: "Change of variables", body: "$\\int_V f = \\int_U (f \\circ \\varphi)\\,|\\det J_\\varphi|$ for a $\\mathcal{C}^1$ diffeomorphism $\\varphi$." },
      { kind: "definition", title: "Polar coordinates", body: "$(x,y) = (r\\cos\\theta, r\\sin\\theta)$; element $dx\\,dy = r\\,dr\\,d\\theta$." },
      { kind: "definition", title: "Cylindrical coordinates", body: "$(r,\\theta,z)$; element $dV = r\\,dr\\,d\\theta\\,dz$." },
      { kind: "definition", title: "Spherical coordinates", body: "$(\\rho,\\varphi,\\theta)$; element $dV = \\rho^2\\sin\\varphi\\,d\\rho\\,d\\varphi\\,d\\theta$." },
      { kind: "note", title: "Applications", body: "Area, volume, mass $\\iint \\rho\\,dA$, centroids, moments of inertia." },
    ],
    formulas: [
      {
        id: "polar",
        name: "Polar coordinates",
        latex: "dx\\,dy = r\\,dr\\,d\\theta",
        meaning: "Area element in $\\mathbb{R}^2$ when using $(r, \\theta)$.",
      },
      {
        id: "spherical",
        name: "Spherical coordinates",
        latex: "dx\\,dy\\,dz = \\rho^2 \\sin\\varphi\\,d\\rho\\,d\\varphi\\,d\\theta",
        meaning: "Volume element in $\\mathbb{R}^3$ for $(\\rho, \\varphi, \\theta)$.",
      },
      {
        id: "centroid",
        name: "Centroid",
        latex: "\\bar{x} = \\frac{1}{\\mathrm{Area}(D)}\\iint_D x\\,dA",
        meaning: "Coordinate of the geometric centre of a planar region.",
      },
    ],
    examples: [
      {
        title: "Area of a disk via polar coordinates",
        statement: "Compute the area of the disk $D = \\{(x,y) : x^2 + y^2 \\le R^2\\}$.",
        steps: [
          "Switch to polar: $D = \\{(r,\\theta) : 0 \\le r \\le R,\\ 0 \\le \\theta \\le 2\\pi\\}$.",
          "Area $= \\iint_D 1\\,dx\\,dy = \\int_0^{2\\pi}\\!\\int_0^R r\\,dr\\,d\\theta$.",
          "$= 2\\pi \\cdot R^2/2 = \\pi R^2$.",
        ],
      },
    ],
    quiz: [
      {
        kind: "input",
        id: "q1",
        prompt: "Jacobian of polar coordinates (enter the factor of $dr\\,d\\theta$).",
        answer: "r",
        explanation: "$\\det J = r$, hence $dx\\,dy = r\\,dr\\,d\\theta$.",
      },
      {
        kind: "input",
        id: "q2",
        prompt: "Volume of a unit ball in $\\mathbb{R}^3$ (enter as multiple of pi, e.g. 4pi/3).",
        answer: "4pi/3",
        accepts: ["4/3 pi", "4*pi/3"],
        explanation: "Spherical coordinates give $\\int_0^{2\\pi}\\!\\int_0^\\pi\\!\\int_0^1 \\rho^2 \\sin\\varphi\\,d\\rho\\,d\\varphi\\,d\\theta = 4\\pi/3$.",
      },
    ],
  },
  {
    id: "vector-int",
    number: 10,
    title: "Line and Surface Integrals",
    part: "Analysis II",
    summary:
      "Parametrised paths, line integrals, conservative fields, Green–Riemann, Stokes, and Gauss–Ostrogradski.",
    blocks: [
      { kind: "definition", title: "Parametrised path", body: "A $\\mathcal{C}^1$ map $\\gamma : [a,b] \\to \\mathbb{R}^n$ tracing a curve." },
      { kind: "definition", title: "Line integral (1st kind)", body: "$\\int_\\gamma f\\,d\\ell = \\int_a^b f(\\gamma(t))\\,\\|\\gamma'(t)\\|\\,dt$ — integrates a scalar along arc length." },
      { kind: "definition", title: "Line integral (2nd kind)", body: "$\\int_\\gamma F \\cdot d\\ell = \\int_a^b F(\\gamma(t)) \\cdot \\gamma'(t)\\,dt$ — work of a vector field." },
      { kind: "definition", title: "Conservative field", body: "$F = \\nabla \\varphi$; line integrals depend only on endpoints." },
      { kind: "theorem", title: "Green–Riemann", body: "$\\oint_{\\partial D} P\\,dx + Q\\,dy = \\iint_D (\\partial_x Q - \\partial_y P)\\,dA$." },
      { kind: "definition", title: "Surface flux", body: "$\\Phi = \\iint_\\Sigma F \\cdot n\\,dS$ — flow of $F$ across the surface." },
      { kind: "theorem", title: "Stokes' theorem", body: "$\\oint_{\\partial \\Sigma} F \\cdot d\\ell = \\iint_\\Sigma (\\nabla \\times F) \\cdot dS$." },
      { kind: "theorem", title: "Gauss–Ostrogradski", body: "$\\oiint_{\\partial V} F \\cdot dS = \\iiint_V \\nabla \\cdot F\\,dV$." },
    ],
    formulas: [
      {
        id: "arc",
        name: "Arc length",
        latex: "L(\\gamma) = \\int_a^b \\|\\gamma'(t)\\|\\,dt",
        meaning: "Length of a $\\mathcal{C}^1$ path.",
      },
      {
        id: "conservative",
        name: "Conservative field",
        latex: "F = \\nabla \\varphi \\Rightarrow \\int_\\gamma F \\cdot d\\ell = \\varphi(\\gamma(b)) - \\varphi(\\gamma(a))",
        meaning: "Path independence: only endpoints matter.",
      },
      {
        id: "flux",
        name: "Surface flux",
        latex: "\\Phi = \\iint_\\Sigma F \\cdot n\\,dS",
        meaning: "Net amount of $F$ crossing $\\Sigma$ in the direction of the unit normal $n$.",
      },
    ],
    examples: [
      {
        title: "Area via Green's formula",
        statement: "Show that the area enclosed by a simple closed curve $\\partial D$ equals $\\tfrac{1}{2}\\oint_{\\partial D} (x\\,dy - y\\,dx)$.",
        steps: [
          "Take $P = -y/2$ and $Q = x/2$ in Green–Riemann.",
          "$\\partial Q/\\partial x - \\partial P/\\partial y = 1/2 - (-1/2) = 1$.",
          "Hence $\\oint_{\\partial D}\\bigl(-y/2\\,dx + x/2\\,dy\\bigr) = \\iint_D 1\\,dA = \\mathrm{Area}(D)$.",
        ],
      },
    ],
    quiz: [
      {
        kind: "mcq",
        id: "q1",
        prompt: "A vector field $F$ is conservative on a simply connected open set iff:",
        choices: [
          "$\\nabla \\cdot F = 0$",
          "$\\nabla \\times F = 0$",
          "$F$ is bounded",
          "$F$ is linear",
        ],
        answer: 1,
        explanation: "On a simply connected domain, curl-free is equivalent to being a gradient.",
      },
      {
        kind: "mcq",
        id: "q2",
        prompt: "Gauss–Ostrogradski links a surface flux integral with:",
        choices: [
          "a line integral",
          "a volume integral of the divergence",
          "a Fourier coefficient",
          "a Jacobian",
        ],
        answer: 1,
        explanation: "$\\oiint F \\cdot dS = \\iiint \\nabla \\cdot F\\,dV$.",
      },
    ],
  },
];

export function findChapter(id: string) {
  return chapters.find((c) => c.id === id);
}

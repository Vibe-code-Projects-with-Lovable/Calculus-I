import { useState } from "react";
import { Button } from "@/components/ui/button";
import { RichText } from "@/lib/math";
import type { Example } from "@/data/chapters";

export function GuidedExample({ example }: { example: Example }) {
  const [shown, setShown] = useState(1);
  const total = example.steps.length;

  return (
    <div className="rounded-lg border border-border bg-card p-4">
      <h3 className="text-base font-semibold">
        <RichText>{example.title}</RichText>
      </h3>
      <p className="mt-1 text-sm text-muted-foreground">
        <RichText>{example.statement}</RichText>
      </p>
      <ol className="mt-4 space-y-3">
        {example.steps.slice(0, shown).map((step, i) => (
          <li key={i} className="flex gap-3">
            <span className="mt-0.5 inline-flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary text-xs font-medium text-primary-foreground">
              {i + 1}
            </span>
            <div className="text-sm leading-relaxed">
              <RichText>{step}</RichText>
            </div>
          </li>
        ))}
      </ol>
      <div className="mt-4 flex items-center gap-2">
        <Button
          size="sm"
          variant="outline"
          onClick={() => setShown((s) => Math.min(total, s + 1))}
          disabled={shown >= total}
        >
          Next step
        </Button>
        <Button size="sm" variant="ghost" onClick={() => setShown(1)} disabled={shown === 1}>
          Reset
        </Button>
        <span className="ml-auto text-xs text-muted-foreground">
          {shown} / {total}
        </span>
      </div>
    </div>
  );
}

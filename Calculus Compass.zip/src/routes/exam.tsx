import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { chapters } from "@/data/chapters";
import { QuizView } from "@/components/QuizView";
import { Button } from "@/components/ui/button";
import { GraduationCap } from "lucide-react";

export const Route = createFileRoute("/exam")({
  head: () => ({
    meta: [
      { title: "Exam simulator — Calculus Companion" },
      {
        name: "description",
        content:
          "Generate a full Analysis I & II practice exam mixing MCQ and calculation questions, with detailed feedback.",
      },
    ],
  }),
  component: ExamPage,
});

function ExamPage() {
  const [mode, setMode] = useState<"setup" | "running">("setup");
  const [picked, setPicked] = useState<Set<string>>(new Set(chapters.map((c) => c.id)));
  const [count, setCount] = useState(8);
  const [seed, setSeed] = useState(0);

  const quiz = useMemo(() => {
    const pool = chapters
      .filter((c) => picked.has(c.id))
      .flatMap((c) => c.quiz.map((q) => ({ ...q })));
    // simple deterministic shuffle from seed
    const arr = [...pool];
    let s = seed || 1;
    for (let i = arr.length - 1; i > 0; i--) {
      s = (s * 9301 + 49297) % 233280;
      const j = Math.floor((s / 233280) * (i + 1));
      [arr[i], arr[j]] = [arr[j], arr[i]];
    }
    return arr.slice(0, count);
  }, [picked, count, seed]);

  const toggle = (id: string) => {
    const next = new Set(picked);
    if (next.has(id)) next.delete(id);
    else next.add(id);
    setPicked(next);
  };

  return (
    <main className="mx-auto max-w-4xl px-4 py-10">
      <header className="mb-8">
        <span className="inline-flex items-center gap-1.5 rounded-full border border-border bg-secondary px-3 py-1 text-xs font-medium text-muted-foreground">
          <GraduationCap className="h-3 w-3" /> Adaptive practice
        </span>
        <h1 className="mt-3 text-3xl font-semibold tracking-tight">Exam simulator</h1>
        <p className="mt-2 max-w-2xl text-muted-foreground">
          Compose a custom set of questions across any subset of the ten chapters. Each answer
          comes with a detailed worked explanation.
        </p>
      </header>

      {mode === "setup" ? (
        <div className="space-y-6 rounded-xl border border-border bg-card p-6">
          <div>
            <label className="text-sm font-medium">Chapters</label>
            <div className="mt-3 grid gap-2 sm:grid-cols-2">
              {chapters.map((c) => (
                <label
                  key={c.id}
                  className="flex cursor-pointer items-center gap-3 rounded-md border border-border px-3 py-2 text-sm hover:bg-muted/60"
                >
                  <input
                    type="checkbox"
                    checked={picked.has(c.id)}
                    onChange={() => toggle(c.id)}
                  />
                  <span className="font-mono text-xs text-muted-foreground">
                    {String(c.number).padStart(2, "0")}
                  </span>
                  <span className="truncate">{c.title}</span>
                </label>
              ))}
            </div>
          </div>
          <div>
            <label className="text-sm font-medium">Number of questions: {count}</label>
            <input
              type="range"
              min={3}
              max={20}
              value={count}
              onChange={(e) => setCount(parseInt(e.target.value))}
              className="mt-2 w-full"
            />
          </div>
          <div className="flex items-center gap-3">
            <Button
              onClick={() => {
                setSeed(Date.now());
                setMode("running");
              }}
              disabled={picked.size === 0}
            >
              Start exam
            </Button>
            <Button variant="ghost" onClick={() => setPicked(new Set(chapters.map((c) => c.id)))}>
              Select all
            </Button>
            <Button variant="ghost" onClick={() => setPicked(new Set())}>
              Clear
            </Button>
          </div>
        </div>
      ) : (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <p className="text-sm text-muted-foreground">
              {quiz.length} questions · {picked.size} chapters
            </p>
            <Button variant="outline" size="sm" onClick={() => setMode("setup")}>
              New exam
            </Button>
          </div>
          <QuizView chapterId="__exam__" quiz={quiz} />
        </div>
      )}
    </main>
  );
}

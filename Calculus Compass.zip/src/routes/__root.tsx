import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  createRootRouteWithContext,
  useRouter,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";

import appCss from "../styles.css?url";
import { AppHeader } from "@/components/AppHeader";
import { ProgressProvider } from "@/lib/progress";

function NotFoundComponent() {
  return (
    <div className="flex min-h-[60vh] items-center justify-center px-4">
      <div className="text-center">
        <h1 className="text-6xl font-bold tracking-tight">404</h1>
        <p className="mt-2 text-sm text-muted-foreground">This page doesn't exist.</p>
        <a
          href="/"
          className="mt-6 inline-flex rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground"
        >
          Back to dashboard
        </a>
      </div>
    </div>
  );
}

function ErrorComponent({ error, reset }: { error: Error; reset: () => void }) {
  console.error(error);
  const router = useRouter();
  return (
    <div className="flex min-h-[60vh] items-center justify-center px-4">
      <div className="max-w-md text-center">
        <h1 className="text-xl font-semibold">Something went wrong</h1>
        <p className="mt-2 text-sm text-muted-foreground">{error.message}</p>
        <button
          onClick={() => {
            router.invalidate();
            reset();
          }}
          className="mt-6 inline-flex rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground"
        >
          Try again
        </button>
      </div>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "Calculus Companion — Master Analysis I & II" },
      {
        name: "description",
        content:
          "Interactive study companion for Mathematical Analysis I & II: theory, formula cheat sheets, sandboxes, and adaptive quizzes.",
      },
      { property: "og:title", content: "Calculus Companion — Master Analysis I & II" },
      {
        property: "og:description",
        content: "Master Analysis I & II with theory, formulas, sandboxes and adaptive quizzes.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:title", content: "Calculus Companion — Master Analysis I & II" },
      { name: "description", content: "Calculus Compass is an interactive web app for mastering Mathematical Analysis I & II." },
      { property: "og:description", content: "Calculus Compass is an interactive web app for mastering Mathematical Analysis I & II." },
      { name: "twitter:description", content: "Calculus Compass is an interactive web app for mastering Mathematical Analysis I & II." },
      { property: "og:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/9114ead8-d19e-4aea-859c-a489de29670a/id-preview-b9d6446d--6a667de0-e4cd-47ec-9a9b-2dffe48b6247.lovable.app-1780064276851.png" },
      { name: "twitter:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/9114ead8-d19e-4aea-859c-a489de29670a/id-preview-b9d6446d--6a667de0-e4cd-47ec-9a9b-2dffe48b6247.lovable.app-1780064276851.png" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "stylesheet", href: appCss }],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();
  return (
    <QueryClientProvider client={queryClient}>
      <ProgressProvider>
        <div className="min-h-screen bg-background text-foreground">
          <AppHeader />
          <Outlet />
        </div>
      </ProgressProvider>
    </QueryClientProvider>
  );
}

import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { MathInline } from "@/lib/math";

export function HessianSandbox() {
  const [r, setR] = useState(2);
  const [s, setS] = useState(1);
  const [t, setT] = useState(2);

  const delta = r * t - s * s;
  let verdict = "Inconclusive (Δ = 0)";
  let tone: "ok" | "warn" | "bad" | "neutral" = "neutral";
  if (delta > 0 && r > 0) {
    verdict = "Local minimum";
    tone = "ok";
  } else if (delta > 0 && r < 0) {
    verdict = "Local maximum";
    tone = "ok";
  } else if (delta < 0) {
    verdict = "Saddle point";
    tone = "bad";
  } else if (delta === 0) {
    tone = "warn";
  }

  return (
    <div className="space-y-4">
      <div className="rounded-lg border border-border bg-card p-4">
        <p className="text-sm text-muted-foreground">
          Enter the Hessian entries <MathInline>{`r = f_{xx},\\ s = f_{xy},\\ t = f_{yy}`}</MathInline>.
          The classifier evaluates <MathInline>{`\\Delta = rt - s^2`}</MathInline>.
        </p>
        <div className="mt-4 grid gap-3 sm:grid-cols-3">
          <Field label="r (f_xx)" value={r} onChange={setR} />
          <Field label="s (f_xy)" value={s} onChange={setS} />
          <Field label="t (f_yy)" value={t} onChange={setT} />
        </div>
      </div>
      <div
        className={
          "rounded-lg border p-4 text-sm " +
          (tone === "ok"
            ? "border-emerald-500/40 bg-emerald-500/10"
            : tone === "bad"
              ? "border-destructive/40 bg-destructive/10"
              : tone === "warn"
                ? "border-amber-500/40 bg-amber-500/10"
                : "border-border bg-secondary/40")
        }
      >
        <div className="font-mono text-xs text-muted-foreground">
          Δ = rt − s² = {r}·{t} − {s}² = {delta}
        </div>
        <div className="mt-1 text-base font-medium">{verdict}</div>
      </div>
    </div>
  );
}

function Field({
  label,
  value,
  onChange,
}: {
  label: string;
  value: number;
  onChange: (n: number) => void;
}) {
  return (
    <div>
      <Label className="text-xs text-muted-foreground">{label}</Label>
      <Input
        type="number"
        step="0.1"
        value={value}
        onChange={(e) => onChange(parseFloat(e.target.value) || 0)}
      />
    </div>
  );
}

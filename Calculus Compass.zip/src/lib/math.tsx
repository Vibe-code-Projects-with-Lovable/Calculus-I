import "katex/dist/katex.min.css";
import katex from "katex";
import { useMemo } from "react";

export function MathInline({ children }: { children: string }) {
  const html = useMemo(
    () =>
      katex.renderToString(children, {
        throwOnError: false,
        displayMode: false,
        output: "html",
      }),
    [children],
  );
  return <span className="katex-inline" dangerouslySetInnerHTML={{ __html: html }} />;
}

export function MathBlock({ children }: { children: string }) {
  const html = useMemo(
    () =>
      katex.renderToString(children, {
        throwOnError: false,
        displayMode: true,
        output: "html",
      }),
    [children],
  );
  return (
    <div
      className="katex-block my-3 overflow-x-auto"
      dangerouslySetInnerHTML={{ __html: html }}
    />
  );
}

/**
 * Render text containing inline `$...$` and block `$$...$$` math.
 */
export function RichText({ children }: { children: string }) {
  const parts = useMemo(() => splitMath(children), [children]);
  return (
    <>
      {parts.map((p, i) => {
        if (p.type === "text") return <span key={i}>{p.value}</span>;
        if (p.type === "inline") return <MathInline key={i}>{p.value}</MathInline>;
        return <MathBlock key={i}>{p.value}</MathBlock>;
      })}
    </>
  );
}

type Part = { type: "text" | "inline" | "block"; value: string };

function splitMath(input: string): Part[] {
  const parts: Part[] = [];
  const re = /(\$\$([\s\S]+?)\$\$)|(\$([^\$\n]+?)\$)/g;
  let last = 0;
  let m: RegExpExecArray | null;
  while ((m = re.exec(input))) {
    if (m.index > last) parts.push({ type: "text", value: input.slice(last, m.index) });
    if (m[2] !== undefined) parts.push({ type: "block", value: m[2].trim() });
    else parts.push({ type: "inline", value: m[4] });
    last = re.lastIndex;
  }
  if (last < input.length) parts.push({ type: "text", value: input.slice(last) });
  return parts;
}
